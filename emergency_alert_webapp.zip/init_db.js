const sqlite3=require('sqlite3').verbose();
const db=new sqlite3.Database('./data.db');
db.serialize(()=>{
 db.run(`CREATE TABLE IF NOT EXISTS ambulances (
   id INTEGER PRIMARY KEY,
   name TEXT,
   phone TEXT,
   latitude REAL,
   longitude REAL,
   status TEXT
 )`);
 db.run(`CREATE TABLE IF NOT EXISTS alerts (
   id INTEGER PRIMARY KEY,
   latitude REAL,
   longitude REAL,
   ambulance_id INTEGER,
   notified INTEGER,
   created_at DATETIME,
   status TEXT
 )`);
 db.run(`INSERT INTO ambulances (name,phone,latitude,longitude,status)
         VALUES ('Ambulance A','+911234567890',12.9719,77.5937,'available')`);
});
db.close();