const express=require('express');
const sqlite3=require('sqlite3').verbose();
const bodyParser=require('body-parser');
const twilio=require('twilio');
const nodemailer=require('nodemailer');
require('dotenv').config();
const app=express();
app.use(bodyParser.json());
const db=new sqlite3.Database('./data.db');
function nearestAmbulanceSql(lat,lon){
  return `((latitude-${lat})*(latitude-${lat})+(longitude-${lon})*(longitude-${lon}))`;
}
app.post('/api/alerts',(req,res)=>{
  const{latitude,longitude}=req.body;
  if(!latitude||!longitude) return res.status(400).json({error:'Missing location'});
  const sql=`SELECT * FROM ambulances WHERE status='available' ORDER BY ${nearestAmbulanceSql(latitude,longitude)} LIMIT 1`;
  db.get(sql,[],(err,amb)=>{
    if(err) return res.status(500).json({error:"DB error"});
    const ambulanceId=amb?amb.id:null;
    const insert=`INSERT INTO alerts (latitude,longitude,ambulance_id,notified,created_at,status)
                  VALUES (?,?,?,?,datetime('now'),'sent')`;
    db.run(insert,[latitude,longitude,ambulanceId,1],function(e){
      if(e) return res.status(500).json({error:"Insert error"});
      const id=this.lastID;
      if(!amb) return res.json({status:'no_ambulance',alertId:id});
      const tw=require('twilio')(process.env.TWILIO_ACCOUNT_SID,process.env.TWILIO_AUTH_TOKEN);
      const msg=`EMERGENCY! Location: https://www.google.com/maps?q=${latitude},${longitude}`;
      tw.messages.create({body:msg,from:process.env.TWILIO_FROM,to:amb.phone})
      .then(()=>{
        db.run(`UPDATE ambulances SET status='busy' WHERE id=?`,[amb.id]);
        res.json({status:'sent',alertId:id,ambulance:amb});
      })
      .catch(()=>res.status(500).json({error:"SMS failed"}));
    });
  });
});
app.listen(3000,()=>console.log("Server running on 3000"));